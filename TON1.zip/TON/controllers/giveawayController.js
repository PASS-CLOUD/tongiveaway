const db = require('../models');
const { Giveaway } = db;
const { v4: uuidv4 } = require('uuid');
const validator = require('validator');

exports.createGiveaway = async (req, res) => {
  const { giveaway, secret } = req.body;

  // Validate the secret token
  if (secret !== process.env.SECRET_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Validate the giveaway data
  const {
    type,
    endsAt,
    tokenAddress,
    amount,
    receiverCount,
    taskUrl,
  } = giveaway;

  if (!['instant', 'lottery'].includes(type)) {
    return res.status(400).json({ error: 'Invalid giveaway type' });
  }

  if (type === 'lottery' && !endsAt) {
    return res.status(400).json({ error: 'endsAt is required for lottery giveaways' });
  }

  if (tokenAddress && !validator.isEthereumAddress(tokenAddress)) {
    return res.status(400).json({ error: 'Invalid token address' });
  }

  if (!validator.isNumeric(amount.toString()) || amount <= 0) {
    return res.status(400).json({ error: 'Amount must be a positive number' });
  }

  if (!validator.isInt(receiverCount.toString(), { min: 1 })) {
    return res.status(400).json({ error: 'receiverCount must be a positive integer' });
  }

  if (taskUrl && !validator.isURL(taskUrl)) {
    return res.status(400).json({ error: 'Invalid task URL' });
  }

  try {
    const newGiveaway = await Giveaway.create({
      ...giveaway,
      id: uuidv4(), // Generate a unique UUID for the giveaway
      status: 'pending',
      participantCount: 0,
    });

    const giveawayLink = `https://my.tt/g/${newGiveaway.id}`;
    const topUpLink = `ton://transfer/${process.env.MAIN_ADDRESS}?token=${newGiveaway.tokenAddress || ''}&amount=${newGiveaway.amount * newGiveaway.receiverCount}&comment=${newGiveaway.id}`;
    const taskToken = newGiveaway.taskUrl ? uuidv4() : undefined;

    return res.status(200).json({ giveawayLink, topUpLink, taskToken });
  } catch (err) {
    console.error('Error creating giveaway:', err);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};