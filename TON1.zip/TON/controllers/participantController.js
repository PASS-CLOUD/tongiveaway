const db = require('../models');
const { Participant, Giveaway } = db;
const axios = require('axios');

exports.getGiveawayStatus = async (req, res) => {
  const { giveawayId } = req.params;

  try {
    const giveaway = await Giveaway.findOne({
      where: { id: giveawayId },
      include: [
        {
          model: Participant,
          attributes: ['status'],
        },
      ],
    });

    if (!giveaway) {
      return res.status(404).json({ error: 'Giveaway not found' });
    }

    const participantCounts = giveaway.Participants.reduce(
      (counts, participant) => {
        counts[participant.status] = (counts[participant.status] || 0) + 1;
        return counts;
      },
      {}
    );

    const giveawayData = {
      ...giveaway.toJSON(),
      participantCounts,
    };

    return res.status(200).json(giveawayData);
  } catch (err) {
    console.error('Error retrieving giveaway status:', err);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.checkinParticipant = async (req, res) => {
  const { giveawayId } = req.params;
  const { captchaToken, receiverAddress, publicKey, signedProof } = req.body;

  try {
    // Validate the captcha token
    const captchaResponse = await axios.post(
      `https://www.google.com/recaptcha/api/siteverify?secret=${process.env.RECAPTCHA_SECRET_KEY}&response=${captchaToken}`
    );

    if (!captchaResponse.data.success) {
      return res.status(400).json({ error: 'Invalid captcha token' });
    }

    // Verify the signature with the public key
    // ... (implement signature verification logic)

    const giveaway = await Giveaway.findOne({ where: { id: giveawayId } });

    if (!giveaway) {
      return res.status(404).json({ error: 'Giveaway not found' });
    }

    const participant = await Participant.create({
      giveawayId,
      receiverAddress,
      status: giveaway.taskUrl ? 'awaitingTask' : 'awaitingPayment',
    });

    return res.status(200).json({ ok: true, giveaway });
  } catch (err) {
    console.error('Error checking in participant:', err);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.completeTask = async (req, res) => {
  const { giveawayId } = req.params;
  const { taskToken, receiverAddress } = req.body;

  try {
    // Validate the taskToken with the external service
    // ... (implement task token validation logic)

    const participant = await Participant.findOne({
      where: {
        giveawayId,
        receiverAddress,
        status: 'awaitingTask',
      },
    });

    if (!participant) {
      return res.status(404).json({
        error: 'Participant not found or task already completed',
      });
    }

    participant.status = 'awaitingPayment';
    await participant.save();

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Error completing task:', err);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};