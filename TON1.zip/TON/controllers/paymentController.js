const db = require('../models');
const { Participant, Giveaway } = db;
const { TonClient } = require('@tonclient/core');
const { mnemonicToWalletKey } = require('ton-crypto');

const tonClient = new TonClient();

exports.makePayments = async () => {
  try {
    const participants = await Participant.findAll({
      where: { status: 'awaitingPayment' },
      include: {
        model: Giveaway,
        where: {
          status: 'active',
        },
      },
    });

    for (const participant of participants) {
      const { receiverAddress, Giveaway } = participant;
      const { amount, tokenAddress } = Giveaway;

      // Check if the giveaway has enough balance
      const walletBalance = await tonClient.getBalance(
        process.env.MAIN_ADDRESS,
        tokenAddress
      );

      if (walletBalance < amount) {
        console.error(
          `Insufficient balance for giveaway ${Giveaway.id}. Required: ${amount}, Available: ${walletBalance}`
        );
        continue;
      }

      // Make payment
      const walletKey = mnemonicToWalletKey(process.env.MAIN_ADDRESS_MNEMONICS);
      const paymentResult = await tonClient.makePayment(
        process.env.MAIN_ADDRESS,
        receiverAddress,
        amount,
        tokenAddress,
        walletKey
      );

      if (paymentResult.success) {
        console.log(`Payment successful to ${receiverAddress}`);
        participant.status = 'paid';
        await participant.save();
      } else {
        console.error(
          `Payment failed to ${receiverAddress}: ${paymentResult.error}`
        );
      }
    }
  } catch (err) {
    console.error('Error making payments:', err);
  }
};

exports.endLotteries = async () => {
  try {
    const lotteries = await Giveaway.findAll({
      where: {
        type: 'lottery',
        status: 'active',
        endsAt: {
          [db.Sequelize.Op.lte]: new Date(),
        },
      },
      include: [
        {
          model: Participant,
          attributes: ['receiverAddress'],
        },
      ],
    });

    for (const lottery of lotteries) {
      const { receiverCount, Participants } = lottery;
      const winners = Participants.map((p) => p.receiverAddress).sort(
        () => 0.5 - Math.random()
      ).slice(0, receiverCount);

      const updatePromises = Participants.map((participant) => {
        participant.status =
          winners.includes(participant.receiverAddress)
            ? 'awaitingPayment'
            : 'lost';
        return participant.save();
      });

      await Promise.all(updatePromises);
      lottery.status = 'finished';
      await lottery.save();
      console.log(`Lottery ${lottery.id} has ended. Winners: ${winners.join(', ')}`);
    }
  } catch (err) {
    console.error('Error ending lotteries:', err);
  }
};