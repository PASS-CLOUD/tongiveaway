const db = require('../models');
const { Giveaway, Participant } = db;
const { Op } = require('sequelize');
const { TonClient } = require('@tonclient/core');

const tonClient = new TonClient();

exports.checkReplenishments = async () => {
  try {
    const giveaways = await Giveaway.findAll({
      where: {
        status: 'pending',
      },
    });

    for (const giveaway of giveaways) {
      const { tokenAddress, amount, receiverCount } = giveaway;
      const requiredBalance = amount * receiverCount;

      const walletBalance = await tonClient.getBalance(
        process.env.MAIN_ADDRESS,
        tokenAddress
      );

      if (walletBalance >= requiredBalance) {
        giveaway.status = 'active';
        await giveaway.save();
        console.log(`Giveaway ${giveaway.id} has been activated.`);
      } else {
        console.log(`Insufficient balance for giveaway ${giveaway.id}.`);
      }
    }
  } catch (err) {
    console.error('Error checking replenishments:', err);
  }
};

exports.updateGiveawayStatuses = async () => {
  try {
    const activeLotteries = await Giveaway.findAll({
      where: {
        type: 'lottery',
        status: 'active',
        endsAt: {
          [Op.lte]: new Date(),
        },
      },
    });

    for (const lottery of activeLotteries) {
      lottery.status = 'finished';
      await lottery.save();
      console.log(`Lottery ${lottery.id} has finished.`);
    }
  } catch (err) {
    console.error('Error updating giveaway statuses:', err);
  }
};

exports.selectWinners = async () => {
  try {
    const finishedLotteries = await Giveaway.findAll({
      where: {
        type: 'lottery',
        status: 'finished',
      },
      include: [
        {
          model: Participant,
          attributes: ['receiverAddress'],
        },
      ],
    });

    for (const lottery of finishedLotteries) {
      const { receiverCount, Participants } = lottery;
      const winners = Participants.map((p) => p.receiverAddress)
        .sort(() => 0.5 - Math.random())
        .slice(0, receiverCount);

      const updatePromises = Participants.map(async (participant) => {
        participant.status = winners.includes(participant.receiverAddress)
          ? 'awaitingPayment'
          : 'lost';
        await participant.save();
      });

      await Promise.all(updatePromises);
      console.log(
        `Lottery ${lottery.id} has ended. Winners: ${winners.join(', ')}`
      );
    }
  } catch (err) {
    console.error('Error selecting winners:', err);
  }
};
