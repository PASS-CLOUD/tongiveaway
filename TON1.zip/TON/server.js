const express = require('express');
const app = express();
const port = 3000;
const db = require('./models');
const giveawayController = require('./controllers/giveawayController');
const cron = require('node-cron');
const replenishmentController = require('./controllers/replenishmentController');
const participantController = require('./controllers/participantController');
const paymentController = require('./controllers/paymentController');
const { selectWinners, checkReplenishments, updateGiveawayStatuses } = require('./controllers/replenishmentController'); // Import the functions
const bot = require('./bot');

const path = require('path');

require('dotenv').config();

app.use(express.json());

db.sequelize.sync()
  .then(() => {
    console.log('Database models synced successfully');
  })
  .catch((err) => {
    console.error('Error syncing database models:', err);
  });

// Serve index.html from the public directory
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

app.post('/giveaways', giveawayController.createGiveaway);

cron.schedule('*/5 * * * * *', async () => {
  try {
    // Check for replenishments and update giveaway statuses
    await checkReplenishments();
    await updateGiveawayStatuses();
  } catch (err) {
    console.error('Error in cron job:', err);
  }
});

cron.schedule('*/5 * * * * *', async () => {
  try {
    await replenishmentController.checkReplenishments();
    await replenishmentController.updateGiveawayStatuses();
    await paymentController.makePayments();
    await selectWinners();
  } catch (err) {
    console.error('Error in cron job:', err);
  }
});

app.get('/giveaways/:giveawayId', participantController.getGiveawayStatus);
app.post('/giveaways/:giveawayId/checkin', participantController.checkinParticipant);
app.post('/giveaways/:giveawayId/complete-task', participantController.completeTask);
app.use(express.static(path.join(__dirname, 'public')));

