module.exports = (sequelize, DataTypes) => {
  const Participant = sequelize.define('Participant', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    giveawayId: {
      type: DataTypes.UUID,
      allowNull: false
    },
    receiverAddress: {
      type: DataTypes.STRING,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('awaitingTask', 'awaitingPayment', 'paid', 'lost'),
      defaultValue: 'awaitingTask'
    },
    publicKey: {
      type: DataTypes.STRING,
      allowNull: false
    },
    signedProof: {
      type: DataTypes.STRING,
      allowNull: false
    },
    captchaToken: {
      type: DataTypes.STRING,
      allowNull: false
    },
    taskToken: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    underscored: true
  });

  Participant.associate = (models) => {
    Participant.belongsTo(models.Giveaway, {
      foreignKey: 'giveawayId',
      onDelete: 'CASCADE'
    });
  };

  Participant.prototype.isEligible = function() {
    return this.status === 'awaitingPayment';
  };

  Participant.prototype.markPaid = function() {
    this.status = 'paid';
    return this.save();
  };

  Participant.prototype.markLost = function() {
    this.status = 'lost';
    return this.save();
  };

  return Participant;
};