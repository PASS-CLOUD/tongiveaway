module.exports = (sequelize, DataTypes) => {
  const Giveaway = sequelize.define(
    'Giveaway',
    {
      type: {
        type: DataTypes.ENUM('instant', 'lottery'),
        allowNull: false,
      },
      endsAt: {
        type: DataTypes.DATE,
        validate: {
          isAfter: new Date().toString(),
        },
      },
      tokenAddress: {
        type: DataTypes.STRING,
        validate: {
          isEthereumAddress: true,
        },
      },
      amount: {
        type: DataTypes.DECIMAL,
        allowNull: false,
        validate: {
          isPositive(value) {
            if (value <= 0) {
              throw new Error('Amount must be a positive number');
            }
          },
        },
      },
      receiverCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
          isInt: true,
          min: 1,
        },
      },
      taskUrl: {
        type: DataTypes.STRING,
        validate: {
          isURL: true,
        },
      },
      status: {
        type: DataTypes.ENUM('pending', 'active', 'finished'),
        defaultValue: 'pending',
      },
      participantCount: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      },
    },
    {
      underscored: true,
    }
  );

  Giveaway.associate = (models) => {
    Giveaway.hasMany(models.Participant, {
      foreignKey: 'giveawayId',
      onDelete: 'CASCADE',
      hooks: true,
    });
  };

  Giveaway.addHook('beforeCreate', (giveaway, options) => {
    if (giveaway.type === 'lottery' && !giveaway.endsAt) {
      throw new Error('endsAt is required for lottery giveaways');
    }
  });

  return Giveaway;
};