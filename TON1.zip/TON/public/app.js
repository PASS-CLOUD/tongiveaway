document.addEventListener('DOMContentLoaded', function () {
  const giveawayForm = document.getElementById('giveaway-form');
  const giveawayList = document.getElementById('giveaway-list');
  const giveawayIdInput = document.getElementById('giveawayId');
  const checkInButton = document.getElementById('checkInButton');
  const messageElement = document.getElementById('message');
  const statusElement = document.getElementById('status');
  const taskInfoElement = document.getElementById('taskInfo');

  giveawayIdInput.addEventListener('input', () => {
      checkInButton.disabled = !giveawayIdInput.value.trim();
  });

  checkInButton.addEventListener('click', async () => {
      const giveawayId = giveawayIdInput.value.trim();
      if (!giveawayId) {
          messageElement.textContent = 'Please enter a Giveaway ID.';
          return;
      }

      try {
          const publicKey = await TONWeb.TonWeb.waitForConnected();
          const signedProof = await TONWeb.TonWeb.sign({ data: giveawayId });
          const captchaToken = await getCaptchaToken(); // Implement captcha verification logic

          const response = await fetch(`/giveaways/${giveawayId}/checkin`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  giveawayId,
                  captchaToken,
                  publicKey,
                  signedProof,
              }),
          });

          const data = await response.json();
          if (data.ok) {
              messageElement.textContent = 'Successfully checked in!';
              displayParticipationStatus(data.giveaway);
          } else {
              messageElement.textContent = data.error;
          }
      } catch (error) {
          console.error(error);
          messageElement.textContent = 'An error occurred. Please try again.';
      }
  });

  // Function to create a new giveaway
  giveawayForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const formData = new FormData(giveawayForm);
      const giveawayData = Object.fromEntries(formData.entries());

      // Send AJAX POST request to create giveaway
      fetch('/giveaways', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({
              giveaway: giveawayData,
              secret: 'clerk' // Replace with actual secret token
          })
      })
      .then(response => {
          if (response.ok) {
              return response.json();
          } else {
              throw new Error('Failed to create giveaway');
          }
      })
      .then(data => {
          // Display giveaway link and top-up link
          const giveawayLink = document.createElement('p');
          giveawayLink.textContent = `Giveaway Link: ${data.giveawayLink}`;
          const topUpLink = document.createElement('p');
          topUpLink.textContent = `Top-up Link: ${data.topUpLink}`;

          const giveawayCard = document.createElement('div');
          giveawayCard.classList.add('giveaway-card');
          giveawayCard.appendChild(giveawayLink);
          giveawayCard.appendChild(topUpLink);

          giveawayList.appendChild(giveawayCard);
      })
      .catch(error => {
          console.error('Error:', error);
      });
  });

  // Function to fetch giveaway status
  function displayParticipationStatus(giveaway) {
      statusElement.classList.remove('hidden');
      statusElement.textContent = `Giveaway Status: ${giveaway.status}`;

      if (giveaway.taskUrl) {
          taskInfoElement.classList.remove('hidden');
          taskInfoElement.innerHTML = `
              <p>Task: <a href="${giveaway.taskUrl}" target="_blank">Complete Task</a></p>
          `;
      }
  }

  function getCaptchaToken() {
      // Implement captcha verification logic here
      // Return a Promise that resolves with the captcha token
      return Promise.resolve('captchaToken');
  }
});
