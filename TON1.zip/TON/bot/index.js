require('dotenv').config(); // Load environment variables from .env file
const { Telegraf, session, Scenes } = require('telegraf');
const axios = require('axios');

// Initialize Telegraf instance with your bot token
const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);

// Initialize Scenes manager
const stage = new Scenes.Stage();

// Middleware to enable session support
bot.use(session());

// Use the middleware for scene management
bot.use(stage.middleware());

// Define your scenes
const createScene = new Scenes.BaseScene('create');

createScene.enter((ctx) =>
  ctx.reply('Select giveaway type:', {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Instant', callback_data: 'instant' }],
        [{ text: 'Lottery', callback_data: 'lottery' }],
      ],
    },
  })
);

createScene.action('instant', async (ctx) => {
  await ctx.reply('Let\'s create a new instant giveaway! Please provide the following details:\nAmount per receiver:\nNumber of receivers:\nToken address (leave blank for Toncoin):\nTask URL (if any):');
  
  // Set the giveaway type to 'instant' in the session
  ctx.session.giveawayType = 'instant';
  
  // Enter the giveaway details scene
  await ctx.scene.enter('giveawayDetails');
});

createScene.action('lottery', async (ctx) => {
  await ctx.reply('Enter giveaway details (amount, receiverCount, tokenAddress, taskUrl, endsAt):');
  ctx.session.giveawayType = 'lottery';
  await ctx.scene.enter('giveawayDetails');
});

const giveawayDetailsScene = new Scenes.BaseScene('giveawayDetails');

giveawayDetailsScene.enter((ctx) => {
  ctx.reply(
    'Please provide the giveaway details as follows: amount, receiverCount, tokenAddress, taskUrl, endsAt (if applicable)'
  );
});

giveawayDetailsScene.on('text', async (ctx) => {
  try {
    const giveawayData = ctx.message.text.split(',').map((item) => item.trim());
    const [amount, receiverCount, tokenAddress, taskUrl, endsAt] = giveawayData;
    const giveaway = {
      amount: parseFloat(amount),
      receiverCount: parseInt(receiverCount, 10),
      tokenAddress: tokenAddress || undefined,
      taskUrl: taskUrl || undefined,
      type: ctx.session.giveawayType,
    };

    if (ctx.session.giveawayType === 'lottery') {
      giveaway.endsAt = new Date(endsAt);
    }

    const apiUrl = process.env.API_URL; // Get API URL from environment variable
    const response = await axios.post(`${apiUrl}/giveaways`, {
      giveaway,
      secret: process.env.SECRET_TOKEN,
    });

    const { giveawayLink, topUpLink, taskToken } = response.data;
    const message = `Giveaway created successfully!
Giveaway Link: ${giveawayLink}
Top-Up Link: ${topUpLink}
${taskToken ? `Task Token: ${taskToken}` : ''}`;

    ctx.reply(message, {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Share Giveaway Link', switch_inline_query: giveawayLink }],
        ],
      },
    });
  } catch (err) {
    console.error('Error creating giveaway:', err);
    ctx.reply('Sorry, an error occurred while creating the giveaway.');
  }
});

// Define a scene for checking giveaway status
const checkStatusScene = new Scenes.BaseScene('checkStatus');

checkStatusScene.enter((ctx) => {
  ctx.reply('Enter the giveaway ID to check its status:');
});

checkStatusScene.on('text', async (ctx) => {
  try {
    const giveawayId = ctx.message.text;
    const apiUrl = process.env.API_URL; // Get API URL from environment variable
    const response = await axios.get(`${apiUrl}/giveaways/${giveawayId}`);
    const giveaway = response.data;

    const message = `Giveaway Status:
Type: ${giveaway.type}
Amount: ${giveaway.amount}
Receiver Count: ${giveaway.receiverCount}
Participant Count: ${giveaway.participantCount}
Status: ${giveaway.status}
${giveaway.endsAt ? `Ends At: ${giveaway.endsAt}` : ''}
${giveaway.tokenAddress ? `Token Address: ${giveaway.tokenAddress}` : ''}
${giveaway.taskUrl ? `Task URL: ${giveaway.taskUrl}` : ''}`;

    ctx.reply(message);
  } catch (err) {
    console.error('Error checking giveaway status:', err);
    ctx.reply('Sorry, an error occurred while checking the giveaway status.');
  }
});

// Register your scenes with the stage
stage.register(createScene);
stage.register(giveawayDetailsScene);
stage.register(checkStatusScene);

// Set up command handlers
bot.start((ctx) => {
  ctx.reply(
    'Welcome to the Giveaway Bot! Choose an action:',
    {
      reply_markup: {
        keyboard: [['Create Giveaway', 'Check Status']],
        one_time_keyboard: true,
      },
    }
  );
});

bot.hears('Create Giveaway', (ctx) => ctx.scene.enter('create'));
bot.hears('Check Status', (ctx) => ctx.scene.enter('checkStatus'));

// Start the bot
bot.launch();
console.log('Telegram bot started');
